CREATE VIEW `view1` AS
    SELECT 
        *
    FROM
        lecciodivina.beadtype;