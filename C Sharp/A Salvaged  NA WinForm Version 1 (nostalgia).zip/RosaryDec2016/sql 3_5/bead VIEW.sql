USE `lecciodivina`;
CREATE  OR REPLACE VIEW `beadview` AS
SELECT 
    beadNumber, beadTypeName, meditationName, verseString
FROM
    lecciodivina.bead,
    lecciodivina.beadtype,
    lecciodivina.meditation,
    lecciodivina.verse
WHERE
    bead.beadtype_FK = beadtype.beadTypeID
        AND bead.meditation_FK = meditation.meditationID
        AND bead.verse_FK = verse.verseID
        AND bead.beadID = 4
;;
