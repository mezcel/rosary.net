﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient; //mysql library, doownload Utilities from the MySql Installer

namespace CSharpMySqlRosary
{
    public partial class frmPrayer : Form
    {
        //connect c# to mysql schema database
        MySqlConnection mcon = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=sumano00");//localhost
        MySqlCommand mcd;
        MySqlDataAdapter mda;
        //MySqlDataReader reader;
        DataTable table;
        
        //--- form drag vvv ----------------------------------------
        private const int WM_NCHITTEST = 0x84;
        private const int HT_CLIENT = 0x1;
        private const int HT_CAPTION = 0x2;
        
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST)
                m.Result = (IntPtr)(HT_CAPTION);
        }
        //--- form drag ^^^ ----------------------------------------
        
        public frmPrayer()
        {
            InitializeComponent();
        }
        
        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu Menu = new frmMenu();
            Menu.StartPosition = FormStartPosition.Manual;
            Menu.Left = this.Left;
            Menu.Top = this.Top;
            Menu.Show();
            this.Close();
        }

        private void frmPrayer_Load(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToShortTimeString();
            loadPrayerNames();
        }

        // --- SQL --- --- ---
        public DataTable getData(string query)
        {
            mcd = new MySqlCommand(query, mcon);
            mda = new MySqlDataAdapter(mcd);
            table = new DataTable();
            mda.Fill(table);
            return table;
        }

        private void loadPrayerNames()
        {
            //name of the prayer
            string query = "SELECT * FROM lecciodivina.prayertype;";
            lbxPrayerName.DataSource = getData(query);
            lbxPrayerName.DisplayMember = "prayerTypeName";
            lbxPrayerName.ValueMember = "prayerTypeID";
        }

        private void loadPrayerText(int prayerType_FK, int leccion_FK)
        {
            //the prayer itself
            string query = "SELECT * FROM lecciodivina.prayertext WHERE (prayerType_FK = " + prayerType_FK + ") AND (leccion_FK = " + leccion_FK + ");";

            lbxPrayerText.DataSource = getData(query);
            lbxPrayerText.DisplayMember = "prayertextString";
            lbxPrayerText.ValueMember = "prayertextID";
        }

        private void lbxPrayerName_SelectedValueChanged(object sender, EventArgs e)
        {
            int leccion_FK;

            if (rdoEnglish.Checked == true)
            { leccion_FK = 1; }
            else if (rdoSpanish.Checked == true)
            { leccion_FK = 2; }
            else 
            { leccion_FK = 3; }

            loadPrayerText(lbxPrayerName.SelectedIndex + 1, leccion_FK);
        }
    }
}
