﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//mysql library, doownload Utilities from the MySql Installer
using MySql.Data.MySqlClient;


namespace CSharpMySqlRosary
{
    public partial class frmRosary : Form
    {
        int beadpos;

        //connect c# to mysql schema database
        MySqlConnection mcon = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=sumano00"); //localhost
        MySqlCommand mcd;
        MySqlDataAdapter mda;
        MySqlDataReader reader;
        DataTable table;

        //--- form drag vvv ----------------------------------------
        private const int WM_NCHITTEST = 0x84;
        private const int HT_CLIENT = 0x1;
        private const int HT_CAPTION = 0x2;
        
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST)
                m.Result = (IntPtr)(HT_CAPTION);
        }
        //--- form drag ^^^ ----------------------------------------
        

        public frmRosary()
        {
            InitializeComponent();
            //designer add-on for animated buttons
            btnBack.MouseDown += new MouseEventHandler(btnBack_MouseDown);
            btnBack.MouseUp += new MouseEventHandler(btnBack_MouseUp);
            btnFwd.MouseDown += new MouseEventHandler(btnFwd_MouseDown);
            btnFwd.MouseUp += new MouseEventHandler(btnFwd_MouseUp);
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu Menu = new frmMenu();
            Menu.StartPosition = FormStartPosition.Manual;
            Menu.Left = this.Left;
            Menu.Top = this.Top;
            Menu.Show();
            this.Close();
        }

        //--- button animation vvv ----------------------------------------
        private void btnBack_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            btnBack.Image = CSharpMySqlRosary.Properties.Resources.thumbButton;
        }

        private void btnBack_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            btnBack.Image = CSharpMySqlRosary.Properties.Resources.MarbleBlock;
        }

        private void btnFwd_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            btnFwd.Image = CSharpMySqlRosary.Properties.Resources.thumbButton;
        }

        private void btnFwd_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            btnFwd.Image = CSharpMySqlRosary.Properties.Resources.MarbleBlock;
        }
        //--- form drag ^^^ ----------------------------------------

        private void btnBack_Click(object sender, EventArgs e)
        {

        }

        private void btnFwd_Click(object sender, EventArgs e)
        {

        }

        private void btnBeadButton_Click(object sender, EventArgs e)
        {
            beadpos = 1;
            dispSqlStuff(beadpos);
        }

        private void frmRosary_Load(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToShortTimeString();
        }

        // --- SQL --- --- ---
        public DataTable getData(string query)
        {
            mcd = new MySqlCommand(query, mcon);
            mda = new MySqlDataAdapter(mcd);
            table = new DataTable();
            mda.Fill(table);
            return table;
        }

        private void dispSqlStuff(int beadpos)
        {
            string query;
            query = "SELECT bookName FROM lecciodivina.book WHERE bookID = " + beadpos + ";";            
            //lblScripture.Text = getData(query).Rows[0][0] + "";
            lblScripture.Text = getData(query).Rows[0][0] + "";
            
        }

        private void btnPevText_Click(object sender, EventArgs e)
        {
            if ((beadpos -1) > 0)
            {
                beadpos = beadpos - 1;
                dispSqlStuff(beadpos);
            }
        }

        private void btnNextText_Click(object sender, EventArgs e)
        {
            if ((beadpos + 1) < 6)
            {
                beadpos = beadpos + 1;
                dispSqlStuff(beadpos);
            }
        }

    }
}
